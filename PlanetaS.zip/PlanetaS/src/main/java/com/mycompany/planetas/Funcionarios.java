/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.planetas;

/**
 *
 * @author Positivo
 */
public class Funcionarios {
    public String nome,nomenovo,cpf,cpfnovo;
    public int nivel, nvnivel,registro,data,reg,id;
}
