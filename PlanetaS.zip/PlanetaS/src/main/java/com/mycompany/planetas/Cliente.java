/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.planetas;

/**
 *
 * @author Positivo
 */
public class Cliente {
   
    public String formapagar,tempnome, cliente,parcelar, produto,categoria,produton;
    public int mesa,a,qnt=0,p,x,s,b,d,id;
    public double svalor,preco,precon,vpago,troco;


}
