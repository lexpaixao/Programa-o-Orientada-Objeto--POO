use funcionarios;
insert into funcionarios(cpf,nome,nascimento,nivel,registro)
values('97433289051','Agatha Pereira Almeida',5031999,2,50389051);
insert into funcionarios(cpf,nome,nascimento,nivel,registro)
values('75687734933','Stephanie Souza Santana',12032000,1,12034933);
insert into funcionarios(cpf,nome,nascimento,nivel,registro)
values('94576236987','Marcelo Silva Nogueira',27012000,0,27016987);
select*from funcionarios;