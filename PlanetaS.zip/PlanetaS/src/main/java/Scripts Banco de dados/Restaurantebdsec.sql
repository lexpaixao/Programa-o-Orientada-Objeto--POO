use restaurante;
insert into restaurante(preco,modelo,categoria)
values (18.90,'Acarajé com Vatapá e Camarão','Porçao');
insert into restaurante (preco,modelo,categoria)
values (26.50,'Moqueca de Peixe com Dendê','Porçao');
insert into restaurante (preco,modelo,categoria)
values (22.90,'Bobó de Camarão','Porçao');
insert into restaurante (preco,modelo,categoria)
values (14.75,'Casquinha de Siri','Porçao');
insert into restaurante (preco,modelo,categoria)
values (12.50,'Pastéis de Carne do Sol','Porçao');
insert into restaurante (preco,modelo,categoria)
values (15.90,'Caipirinha de Cachaça com Frutas Tropicais','Bebidas'); 
insert into restaurante (preco,modelo,categoria)
values (6.50,'Água de Coco Gelada','Bebidas');
insert into restaurante (preco,modelo,categoria)
values (18.50,'Capeta ','Bebidas');
insert into restaurante (preco,modelo,categoria)
values (7.90,'Suco de Caju Natural','Bebidas');
insert into restaurante (preco,modelo,categoria)
values (10.50,'Cerveja Artesanal Local','Bebidas');
insert into restaurante (preco,modelo,categoria)
values (14.90,'Salada de Palmito com Molho de Maracujá','Entrada');
insert into restaurante (preco,modelo,categoria)
values (9.75,'Caldo de Sururu','Entrada');
insert into restaurante (preco,modelo,categoria)
values (11.50,'Bolinho de Feijoada com Molho de Pimenta','Entrada');
insert into restaurante (preco,modelo,categoria)
values (13.25,'Espetinho de Queijo Coalho com Mel de Engenho','Entrada');
insert into restaurante (preco,modelo,categoria)
values (16.90,'Salada de Bacalhau com Grão-de-Bico','Entrada');
insert into restaurante (preco,modelo,categoria)
values (32.90,'Moqueca de Peixe com Arroz de Coco e Farofa','Prato Principal');
insert into restaurante (preco,modelo,categoria)
values (29.50,'Caruru com Camarão Seco, Vatapá e Arroz','Prato Principal');
insert into restaurante (preco,modelo,categoria)
values (25.75,'Ensopado de Siri com Banana da Terra','Prato Principal');
insert into restaurante (preco,modelo,categoria)
values (28.90,'Feijoada Baiana com Arroz, Couve e Laranja','Prato Principal');
insert into restaurante (preco,modelo,categoria)
values (34.50,'Camarões na Moranga com Catupiry e Pirão','Prato Principal');
select * from restaurante;
