use historico;
insert into historico(cliente,mesa,pedido,quantidade,preco,valor,pagamento)
values('Alexia', 6,'Água de Coco Gelada',2,6.50,6.50,'Dinheiro');
select * from historico;